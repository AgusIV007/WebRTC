import aiohttp
import aiohttp_jinja2
import jinja2
from aiohttp import web
from aiortc import RTCSessionDescription

routes = web.RouteTableDef()
pending_offers = []
pending_answers = []
usuarios = False

@aiohttp_jinja2.template('index.html')
async def index(request):
    return {}

@routes.post('/offer1')
async def offer1(request):
    global pending_offers
    global pending_answers
    
    pending_offers = []
    pending_answers = []
    params = await request.json()
    offer = RTCSessionDescription(sdp=params['sdp'], type=params['type'])
    pending_offers.append(offer)
    return web.json_response({'status': 'ok'})

@routes.post('/offer2')
async def offer2(request):
    pending_offer = pending_offers[0]
    return web.json_response({
        'offer': { 'type': pending_offer.type, 'sdp': pending_offer.sdp},
    })

@routes.post('/usuario')
async def usuario(request):
    global usuarios
    usuarios = not(usuarios)
    return web.json_response({
        'usuario': usuarios,
    })
    
@routes.post('/answer1')
async def answer1(request):
    params = await request.json()
    answer = RTCSessionDescription(sdp=params['sdp'], type=params['type'])
    pending_answers.append(answer)
    return web.json_response({'status': 'ok'})

@routes.post('/answer2')
async def answer2(request):
    if len(pending_answers) != 0:
        pending_answer = pending_answers[0]
        return web.json_response({
            'answer': {'type': pending_answer.type, 'sdp': pending_answer.sdp},
        })
    else:
        return web.json_response({
            'waiting': True,
        })

async def on_shutdown(app):
    pending_offers.clear()

app = web.Application()
app.on_shutdown.append(on_shutdown)
aiohttp_jinja2.setup(app, loader=jinja2.FileSystemLoader('templates'))

app.router.add_static('/static/', path='static')
app.router.add_get('/', index)
app.router.add_post('/offer1', offer1)
app.router.add_post('/offer2', offer2)
app.router.add_post('/answer1', answer1)
app.router.add_post('/answer2', answer2)
app.router.add_post('/usuario', usuario)

web.run_app(app, host='0.0.0.0', port=8080)