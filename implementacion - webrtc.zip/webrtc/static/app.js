let pc = new RTCPeerConnection();
let dataChannel;
let localstream;


//Evento que detecta el envio del video
pc.ontrack = e => {
    remoteVideo.srcObject = e.streams[0];
};

async function init() {
    try{
        localstream = await navigator.mediaDevices.getUserMedia({ video: true });
        const remoteVideo = document.getElementById('remoteVideo');
        remoteVideo.srcObject = localstream;
        localstream.getTracks().forEach(track => pc.addTrack(track, localstream));
    } catch (error) {
        console.error('Error, no hay video', error);
    }
    const response = await fetch('/usuario', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
    });
    const result = await response.json();
    const usuarios = result.usuario;
    console.log(usuarios);
    if (usuarios) {
        await Primero();
    } else {
        await Segundo();
    }
    setTimeout(Reenvio, 5000);
}

//Evento para el canal de datos, para la entrada de mensajes o para cuando se abra la conexion

pc.ondatachannel = event => {
    dataChannel = event.channel;
    dataChannel.onmessage = e => {
        const mensajes = document.getElementById('mensajes');
        mensajes.value += `\n${e.data}`;
    };
    dataChannel.onopen = () => {
        console.log('Canal de datos abierto');
    };
};

//Evento para cuando se detecte un candidato de conexion

pc.onicecandidate = event => {
    if (event.candidate) {
        console.log('ICEcandidate:' + JSON.stringify(pc.localDescription));
    }
};

//Funcion que manda mensaje solo si esta el canal de datos abierto

async function MandarMensaje() {
    const input = document.getElementById('input');
    const mensaje = input.value;
    input.value = '';

    if (dataChannel && dataChannel.readyState === 'open') {
        dataChannel.send(mensaje);
        const mensajes = document.getElementById('mensajes');
        mensajes.value += `\nVos: ${mensaje}`;
    } else {
        console.log('Canal de datos cerrado');
    }
}

document.getElementById('boton').addEventListener('click', MandarMensaje);

//El primer usuario crea su oferta para la conexion peer2peer y la envia al servidor

async function Primero() {
    const offer = await pc.createOffer();
    await pc.setLocalDescription(offer);
    setTimeout(respuestaPrimero, 3000);
    await fetch('/offer1', {
        method: 'POST',
        body: JSON.stringify(pc.localDescription),
        headers: { 'Content-Type': 'application/json' }
    });
}

//El segundo usuario pide la oferta al servidor para la conexion peer2peer, y crea una respuesta de esa oferta y la envia al servidor

async function Segundo() {
    const response = await fetch('/offer2', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
    });
    const result = await response.json();
    await pc.setRemoteDescription(result.offer);
    const answer = await pc.createAnswer();
    await pc.setLocalDescription(answer);
    await fetch('/answer1', {
        method: 'POST',
        body: JSON.stringify({ type: answer.type, sdp: answer.sdp }),
        headers: { 'Content-Type': 'application/json' }
    });
}

//El primer usuario espera constantemente una respuesta del servidor

async function respuestaPrimero() {
    console.log(JSON.stringify(pc.localDescription))
    const response = await fetch('/answer2', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
    });
    const result = await response.json();
    if (result.waiting) {
        console.log("Esperando conexion...");
        setTimeout(respuestaPrimero, 3000);
    } else {
        await pc.setRemoteDescription(result.answer);
    }
}


dataChannel = pc.createDataChannel("chat");

//Funcion hecha para reenviar las ofertas y respuestas

async function Reenvio() {
    const responsee = await fetch('/usuario', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
    });
    const resultt = await responsee.json();
    const usuarios = resultt.usuario;
    if (usuarios) {
        await primeraconexion1();
    } else {
        await primeraconexion2();
    }
    if (dataChannel.readyState !== 'open') {
        if (usuarios) {
            await segundaconexion2();
        } else {
            await segundaconexion1();
        }
    }
    const remoteVideo = document.getElementById('remoteVideo');     
    try{
            navigator.mediaDevices.getUserMedia({video: true}).then (function(stream) {
            pc.ontrack = e => remoteVideo.srcObject = e.streams[0];
            stream.getTracks().forEach(track => pc.addTrack(track, stream));
        })
        
    } catch (error) {
        console.error('Error, no hay video.', error);
    }
}

//Evento del canal de datos cuando se abre

dataChannel.onopen = () => {
    console.log('Canal de datos cerrado');
    dataChannel.send('Bienvenido al chat!');
};

//Evento del canal de datos cuando se manda un mensaje

dataChannel.onmessage = event => {
    const mensajes = document.getElementById('mensajes');
    mensajes.value += `\n${event.data}`;
};

//Se reenvia la oferta

async function primeraconexion1() {
    await fetch('/offer1', {
        method: 'POST',
        body: JSON.stringify(pc.localDescription),
        headers: { 'Content-Type': 'application/json' }
    });
}

//Se vuelve a pedir la oferta

async function primeraconexion2() {
    const response = await fetch('/offer2', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
    });
    const result = await response.json();
    await pc.setRemoteDescription(result.offer);
}

//Se reenvia la respuesta

async function segundaconexion1() {
    await fetch('/answer1', {
        method: 'POST',
        body: JSON.stringify(pc.localDescription),
        headers: { 'Content-Type': 'application/json' }
    });
}

//Se vuelve a pedir la respuesta

async function segundaconexion2() {
    const response = await fetch('/answer2', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
    });
    const result = await response.json();
    await pc.setRemoteDescription(result.answer);
}

init();